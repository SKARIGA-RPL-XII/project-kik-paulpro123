import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminController::approval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
export const approval = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approval.url(options),
    method: 'get',
})

approval.definition = {
    methods: ["get","head"],
    url: '/admin/akun-approval',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::approval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
approval.url = (options?: RouteQueryOptions) => {
    return approval.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::approval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
approval.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: approval.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminController::approval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
approval.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: approval.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::approval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
    const approvalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: approval.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::approval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
        approvalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: approval.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminController::approval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
        approvalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: approval.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    approval.form = approvalForm
const accounts = {
    approval: Object.assign(approval, approval),
}

export default accounts