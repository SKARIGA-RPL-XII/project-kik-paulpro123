import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminController::approve
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
export const approve = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/admin/eo/{eo}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::approve
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
approve.url = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { eo: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { eo: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    eo: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        eo: typeof args.eo === 'object'
                ? args.eo.id
                : args.eo,
                }

    return approve.definition.url
            .replace('{eo}', parsedArgs.eo.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::approve
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
approve.post = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::approve
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
    const approveForm = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::approve
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
        approveForm.post = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
export const reject = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/admin/eo/{eo}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
reject.url = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { eo: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { eo: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    eo: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        eo: typeof args.eo === 'object'
                ? args.eo.id
                : args.eo,
                }

    return reject.definition.url
            .replace('{eo}', parsedArgs.eo.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
reject.post = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
    const rejectForm = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
        rejectForm.post = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
const eo = {
    approve: Object.assign(approve, approve),
reject: Object.assign(reject, reject),
}

export default eo