<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Fortify\TwoFactorAuthenticatable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable, TwoFactorAuthenticatable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'status',
        'parent_user_id',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'two_factor_secret',
        'two_factor_recovery_codes',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'two_factor_confirmed_at' => 'datetime',
        ];
    }
    public function eoAccount()
    {
        return $this->hasOne(User::class, 'parent_user_id');
    }

    public function eventOrganizer()
    {
        return $this->hasOne(EventOrganizer::class);
    }

    public function owner()
    {
        return $this->belongsTo(User::class, 'parent_user_id');
    }

    public function isUser()
    {
        return $this->role === 'user';
    }

    public function isEO()
    {
        return $this->role === 'eo';
    }

    public function isAdmin()
    {
        return $this->role === 'admin';
    }
    public function parentUser()
    {
        return $this->belongsTo(User::class, 'parent_user_id');
    }
    public function customerDetail()
    {
        return $this->hasOne(CustomerDetail::class);
    }
}
