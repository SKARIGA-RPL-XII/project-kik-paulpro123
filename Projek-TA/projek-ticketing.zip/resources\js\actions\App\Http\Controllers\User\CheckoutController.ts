import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\User\CheckoutController::customer
 * @see app/Http/Controllers/User/CheckoutController.php:38
 * @route '/checkout/customer'
 */
export const customer = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customer.url(options),
    method: 'get',
})

customer.definition = {
    methods: ["get","head"],
    url: '/checkout/customer',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\CheckoutController::customer
 * @see app/Http/Controllers/User/CheckoutController.php:38
 * @route '/checkout/customer'
 */
customer.url = (options?: RouteQueryOptions) => {
    return customer.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\CheckoutController::customer
 * @see app/Http/Controllers/User/CheckoutController.php:38
 * @route '/checkout/customer'
 */
customer.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: customer.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\CheckoutController::customer
 * @see app/Http/Controllers/User/CheckoutController.php:38
 * @route '/checkout/customer'
 */
customer.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: customer.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\CheckoutController::customer
 * @see app/Http/Controllers/User/CheckoutController.php:38
 * @route '/checkout/customer'
 */
    const customerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: customer.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\CheckoutController::customer
 * @see app/Http/Controllers/User/CheckoutController.php:38
 * @route '/checkout/customer'
 */
        customerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: customer.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\CheckoutController::customer
 * @see app/Http/Controllers/User/CheckoutController.php:38
 * @route '/checkout/customer'
 */
        customerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: customer.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    customer.form = customerForm
/**
* @see \App\Http\Controllers\User\CheckoutController::storeCustomer
 * @see app/Http/Controllers/User/CheckoutController.php:46
 * @route '/checkout/customer'
 */
export const storeCustomer = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCustomer.url(options),
    method: 'post',
})

storeCustomer.definition = {
    methods: ["post"],
    url: '/checkout/customer',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\CheckoutController::storeCustomer
 * @see app/Http/Controllers/User/CheckoutController.php:46
 * @route '/checkout/customer'
 */
storeCustomer.url = (options?: RouteQueryOptions) => {
    return storeCustomer.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\CheckoutController::storeCustomer
 * @see app/Http/Controllers/User/CheckoutController.php:46
 * @route '/checkout/customer'
 */
storeCustomer.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCustomer.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\CheckoutController::storeCustomer
 * @see app/Http/Controllers/User/CheckoutController.php:46
 * @route '/checkout/customer'
 */
    const storeCustomerForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeCustomer.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\CheckoutController::storeCustomer
 * @see app/Http/Controllers/User/CheckoutController.php:46
 * @route '/checkout/customer'
 */
        storeCustomerForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeCustomer.url(options),
            method: 'post',
        })
    
    storeCustomer.form = storeCustomerForm
/**
* @see \App\Http\Controllers\User\CheckoutController::checkout
 * @see app/Http/Controllers/User/CheckoutController.php:15
 * @route '/checkout'
 */
export const checkout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

checkout.definition = {
    methods: ["post"],
    url: '/checkout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\CheckoutController::checkout
 * @see app/Http/Controllers/User/CheckoutController.php:15
 * @route '/checkout'
 */
checkout.url = (options?: RouteQueryOptions) => {
    return checkout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\CheckoutController::checkout
 * @see app/Http/Controllers/User/CheckoutController.php:15
 * @route '/checkout'
 */
checkout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: checkout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\CheckoutController::checkout
 * @see app/Http/Controllers/User/CheckoutController.php:15
 * @route '/checkout'
 */
    const checkoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: checkout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\CheckoutController::checkout
 * @see app/Http/Controllers/User/CheckoutController.php:15
 * @route '/checkout'
 */
        checkoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: checkout.url(options),
            method: 'post',
        })
    
    checkout.form = checkoutForm
/**
* @see \App\Http\Controllers\User\CheckoutController::createOrder
 * @see app/Http/Controllers/User/CheckoutController.php:75
 * @route '/checkout/create-order'
 */
export const createOrder = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createOrder.url(options),
    method: 'post',
})

createOrder.definition = {
    methods: ["post"],
    url: '/checkout/create-order',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\CheckoutController::createOrder
 * @see app/Http/Controllers/User/CheckoutController.php:75
 * @route '/checkout/create-order'
 */
createOrder.url = (options?: RouteQueryOptions) => {
    return createOrder.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\CheckoutController::createOrder
 * @see app/Http/Controllers/User/CheckoutController.php:75
 * @route '/checkout/create-order'
 */
createOrder.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: createOrder.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\CheckoutController::createOrder
 * @see app/Http/Controllers/User/CheckoutController.php:75
 * @route '/checkout/create-order'
 */
    const createOrderForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: createOrder.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\CheckoutController::createOrder
 * @see app/Http/Controllers/User/CheckoutController.php:75
 * @route '/checkout/create-order'
 */
        createOrderForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: createOrder.url(options),
            method: 'post',
        })
    
    createOrder.form = createOrderForm
const CheckoutController = { customer, storeCustomer, checkout, createOrder }

export default CheckoutController