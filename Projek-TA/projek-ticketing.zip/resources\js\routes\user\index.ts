import events from './events'
const user = {
    events: Object.assign(events, events),
}

export default user