import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\User\PaymentController::paymentPage
 * @see app/Http/Controllers/User/PaymentController.php:15
 * @route '/checkout/payment/{id}'
 */
export const paymentPage = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paymentPage.url(args, options),
    method: 'get',
})

paymentPage.definition = {
    methods: ["get","head"],
    url: '/checkout/payment/{id}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\PaymentController::paymentPage
 * @see app/Http/Controllers/User/PaymentController.php:15
 * @route '/checkout/payment/{id}'
 */
paymentPage.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return paymentPage.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::paymentPage
 * @see app/Http/Controllers/User/PaymentController.php:15
 * @route '/checkout/payment/{id}'
 */
paymentPage.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: paymentPage.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\PaymentController::paymentPage
 * @see app/Http/Controllers/User/PaymentController.php:15
 * @route '/checkout/payment/{id}'
 */
paymentPage.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: paymentPage.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::paymentPage
 * @see app/Http/Controllers/User/PaymentController.php:15
 * @route '/checkout/payment/{id}'
 */
    const paymentPageForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: paymentPage.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::paymentPage
 * @see app/Http/Controllers/User/PaymentController.php:15
 * @route '/checkout/payment/{id}'
 */
        paymentPageForm.get = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paymentPage.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\PaymentController::paymentPage
 * @see app/Http/Controllers/User/PaymentController.php:15
 * @route '/checkout/payment/{id}'
 */
        paymentPageForm.head = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: paymentPage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    paymentPage.form = paymentPageForm
/**
* @see \App\Http\Controllers\User\PaymentController::verify
 * @see app/Http/Controllers/User/PaymentController.php:27
 * @route '/checkout/verify-payment'
 */
export const verify = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(options),
    method: 'post',
})

verify.definition = {
    methods: ["post"],
    url: '/checkout/verify-payment',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\User\PaymentController::verify
 * @see app/Http/Controllers/User/PaymentController.php:27
 * @route '/checkout/verify-payment'
 */
verify.url = (options?: RouteQueryOptions) => {
    return verify.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::verify
 * @see app/Http/Controllers/User/PaymentController.php:27
 * @route '/checkout/verify-payment'
 */
verify.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::verify
 * @see app/Http/Controllers/User/PaymentController.php:27
 * @route '/checkout/verify-payment'
 */
    const verifyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verify.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::verify
 * @see app/Http/Controllers/User/PaymentController.php:27
 * @route '/checkout/verify-payment'
 */
        verifyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verify.url(options),
            method: 'post',
        })
    
    verify.form = verifyForm
/**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:58
 * @route '/checkout/success'
 */
export const success = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: success.url(options),
    method: 'get',
})

success.definition = {
    methods: ["get","head"],
    url: '/checkout/success',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:58
 * @route '/checkout/success'
 */
success.url = (options?: RouteQueryOptions) => {
    return success.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:58
 * @route '/checkout/success'
 */
success.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: success.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:58
 * @route '/checkout/success'
 */
success.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: success.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:58
 * @route '/checkout/success'
 */
    const successForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: success.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:58
 * @route '/checkout/success'
 */
        successForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: success.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\PaymentController::success
 * @see app/Http/Controllers/User/PaymentController.php:58
 * @route '/checkout/success'
 */
        successForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: success.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    success.form = successForm
/**
* @see \App\Http\Controllers\User\PaymentController::failed
 * @see app/Http/Controllers/User/PaymentController.php:71
 * @route '/checkout/failed'
 */
export const failed = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: failed.url(options),
    method: 'get',
})

failed.definition = {
    methods: ["get","head"],
    url: '/checkout/failed',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\PaymentController::failed
 * @see app/Http/Controllers/User/PaymentController.php:71
 * @route '/checkout/failed'
 */
failed.url = (options?: RouteQueryOptions) => {
    return failed.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\PaymentController::failed
 * @see app/Http/Controllers/User/PaymentController.php:71
 * @route '/checkout/failed'
 */
failed.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: failed.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\PaymentController::failed
 * @see app/Http/Controllers/User/PaymentController.php:71
 * @route '/checkout/failed'
 */
failed.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: failed.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\PaymentController::failed
 * @see app/Http/Controllers/User/PaymentController.php:71
 * @route '/checkout/failed'
 */
    const failedForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: failed.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\PaymentController::failed
 * @see app/Http/Controllers/User/PaymentController.php:71
 * @route '/checkout/failed'
 */
        failedForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: failed.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\PaymentController::failed
 * @see app/Http/Controllers/User/PaymentController.php:71
 * @route '/checkout/failed'
 */
        failedForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: failed.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    failed.form = failedForm
const PaymentController = { paymentPage, verify, success, failed }

export default PaymentController