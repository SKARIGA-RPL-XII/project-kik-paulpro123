import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\AdminController::index
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/manage-akun',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::index
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::index
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminController::index
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::index
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::index
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminController::index
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\AdminController::eoApproval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
export const eoApproval = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: eoApproval.url(options),
    method: 'get',
})

eoApproval.definition = {
    methods: ["get","head"],
    url: '/admin/akun-approval',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::eoApproval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
eoApproval.url = (options?: RouteQueryOptions) => {
    return eoApproval.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::eoApproval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
eoApproval.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: eoApproval.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminController::eoApproval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
eoApproval.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: eoApproval.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::eoApproval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
    const eoApprovalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: eoApproval.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::eoApproval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
        eoApprovalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: eoApproval.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminController::eoApproval
 * @see app/Http/Controllers/Admin/AdminController.php:20
 * @route '/admin/akun-approval'
 */
        eoApprovalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: eoApproval.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    eoApproval.form = eoApprovalForm
/**
* @see \App\Http\Controllers\Admin\AdminController::approveEO
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
export const approveEO = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveEO.url(args, options),
    method: 'post',
})

approveEO.definition = {
    methods: ["post"],
    url: '/admin/eo/{eo}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::approveEO
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
approveEO.url = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { eo: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { eo: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    eo: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        eo: typeof args.eo === 'object'
                ? args.eo.id
                : args.eo,
                }

    return approveEO.definition.url
            .replace('{eo}', parsedArgs.eo.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::approveEO
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
approveEO.post = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveEO.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::approveEO
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
    const approveEOForm = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approveEO.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::approveEO
 * @see app/Http/Controllers/Admin/AdminController.php:40
 * @route '/admin/eo/{eo}/approve'
 */
        approveEOForm.post = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveEO.url(args, options),
            method: 'post',
        })
    
    approveEO.form = approveEOForm
/**
* @see \App\Http\Controllers\Admin\AdminController::rejectEO
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
export const rejectEO = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectEO.url(args, options),
    method: 'post',
})

rejectEO.definition = {
    methods: ["post"],
    url: '/admin/eo/{eo}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::rejectEO
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
rejectEO.url = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { eo: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { eo: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    eo: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        eo: typeof args.eo === 'object'
                ? args.eo.id
                : args.eo,
                }

    return rejectEO.definition.url
            .replace('{eo}', parsedArgs.eo.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::rejectEO
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
rejectEO.post = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectEO.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::rejectEO
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
    const rejectEOForm = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rejectEO.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::rejectEO
 * @see app/Http/Controllers/Admin/AdminController.php:50
 * @route '/admin/eo/{eo}/reject'
 */
        rejectEOForm.post = (args: { eo: number | { id: number } } | [eo: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rejectEO.url(args, options),
            method: 'post',
        })
    
    rejectEO.form = rejectEOForm
/**
* @see \App\Http\Controllers\Admin\AdminController::eventApproval
 * @see app/Http/Controllers/Admin/AdminController.php:73
 * @route '/admin/event-approval'
 */
export const eventApproval = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: eventApproval.url(options),
    method: 'get',
})

eventApproval.definition = {
    methods: ["get","head"],
    url: '/admin/event-approval',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::eventApproval
 * @see app/Http/Controllers/Admin/AdminController.php:73
 * @route '/admin/event-approval'
 */
eventApproval.url = (options?: RouteQueryOptions) => {
    return eventApproval.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::eventApproval
 * @see app/Http/Controllers/Admin/AdminController.php:73
 * @route '/admin/event-approval'
 */
eventApproval.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: eventApproval.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminController::eventApproval
 * @see app/Http/Controllers/Admin/AdminController.php:73
 * @route '/admin/event-approval'
 */
eventApproval.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: eventApproval.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::eventApproval
 * @see app/Http/Controllers/Admin/AdminController.php:73
 * @route '/admin/event-approval'
 */
    const eventApprovalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: eventApproval.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::eventApproval
 * @see app/Http/Controllers/Admin/AdminController.php:73
 * @route '/admin/event-approval'
 */
        eventApprovalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: eventApproval.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminController::eventApproval
 * @see app/Http/Controllers/Admin/AdminController.php:73
 * @route '/admin/event-approval'
 */
        eventApprovalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: eventApproval.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    eventApproval.form = eventApprovalForm
/**
* @see \App\Http\Controllers\Admin\AdminController::publish
 * @see app/Http/Controllers/Admin/AdminController.php:60
 * @route '/admin/events/{event}/publish'
 */
export const publish = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publish.url(args, options),
    method: 'patch',
})

publish.definition = {
    methods: ["patch"],
    url: '/admin/events/{event}/publish',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::publish
 * @see app/Http/Controllers/Admin/AdminController.php:60
 * @route '/admin/events/{event}/publish'
 */
publish.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return publish.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::publish
 * @see app/Http/Controllers/Admin/AdminController.php:60
 * @route '/admin/events/{event}/publish'
 */
publish.patch = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: publish.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::publish
 * @see app/Http/Controllers/Admin/AdminController.php:60
 * @route '/admin/events/{event}/publish'
 */
    const publishForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: publish.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::publish
 * @see app/Http/Controllers/Admin/AdminController.php:60
 * @route '/admin/events/{event}/publish'
 */
        publishForm.patch = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: publish.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    publish.form = publishForm
/**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:68
 * @route '/admin/events/{event}/reject'
 */
export const reject = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

reject.definition = {
    methods: ["patch"],
    url: '/admin/events/{event}/reject',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:68
 * @route '/admin/events/{event}/reject'
 */
reject.url = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { event: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { event: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    event: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        event: typeof args.event === 'object'
                ? args.event.id
                : args.event,
                }

    return reject.definition.url
            .replace('{event}', parsedArgs.event.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:68
 * @route '/admin/events/{event}/reject'
 */
reject.patch = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: reject.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:68
 * @route '/admin/events/{event}/reject'
 */
    const rejectForm = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::reject
 * @see app/Http/Controllers/Admin/AdminController.php:68
 * @route '/admin/events/{event}/reject'
 */
        rejectForm.patch = (args: { event: number | { id: number } } | [event: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    reject.form = rejectForm
const AdminController = { index, eoApproval, approveEO, rejectEO, eventApproval, publish, reject }

export default AdminController