import RegisterEOController from './RegisterEOController'
import EventController from './EventController'
import EoTicketController from './EoTicketController'
const Eo = {
    RegisterEOController: Object.assign(RegisterEOController, RegisterEOController),
EventController: Object.assign(EventController, EventController),
EoTicketController: Object.assign(EoTicketController, EoTicketController),
}

export default Eo