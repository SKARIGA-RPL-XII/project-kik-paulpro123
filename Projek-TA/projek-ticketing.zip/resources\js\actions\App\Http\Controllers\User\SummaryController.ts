import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\User\SummaryController::summary
 * @see app/Http/Controllers/User/SummaryController.php:12
 * @route '/checkout/summary'
 */
export const summary = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})

summary.definition = {
    methods: ["get","head"],
    url: '/checkout/summary',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\User\SummaryController::summary
 * @see app/Http/Controllers/User/SummaryController.php:12
 * @route '/checkout/summary'
 */
summary.url = (options?: RouteQueryOptions) => {
    return summary.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\User\SummaryController::summary
 * @see app/Http/Controllers/User/SummaryController.php:12
 * @route '/checkout/summary'
 */
summary.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: summary.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\User\SummaryController::summary
 * @see app/Http/Controllers/User/SummaryController.php:12
 * @route '/checkout/summary'
 */
summary.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: summary.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\User\SummaryController::summary
 * @see app/Http/Controllers/User/SummaryController.php:12
 * @route '/checkout/summary'
 */
    const summaryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: summary.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\User\SummaryController::summary
 * @see app/Http/Controllers/User/SummaryController.php:12
 * @route '/checkout/summary'
 */
        summaryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\User\SummaryController::summary
 * @see app/Http/Controllers/User/SummaryController.php:12
 * @route '/checkout/summary'
 */
        summaryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: summary.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    summary.form = summaryForm
const SummaryController = { summary }

export default SummaryController