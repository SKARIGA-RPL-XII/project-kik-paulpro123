<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Event;
use App\Models\Order;
use Inertia\Inertia;

class PaymentController extends Controller
{

    public function paymentPage($id)
    {
        $order = Order::findOrFail($id);

        $event = Event::find($order->event_id);

        return Inertia::render('user/payment', [
            'order' => $order,
            'event' => $event
        ]);
    }

    public function verify(Request $request)
    {
        $request->validate([
            'order_id' => 'required',
            'payment_proof' => 'required|image|mimes:jpg,jpeg,png|max:2048'
        ]);

        $order = Order::where('id', $request->order_id)
            ->where('status', 'pending')
            ->first();

        if (!$order) {
            return redirect('/checkout/failed');
        }

        // simpan bukti pembayaran
        $path = $request->file('payment_proof')
            ->store('payment_proofs', 'public');

        $order->payment_proof = $path;
        $order->status = 'verifying';
        $order->save();

        sleep(2);

        $order->status = 'success';
        $order->save();

        return redirect('/checkout/success');
    }

    public function success()
    {
        $order = Order::with('event')
            ->where('user_id', Auth::id())
            ->latest()
            ->first();

        return Inertia::render('user/success', [
            'order' => $order,
            'event' => $order->event
        ]);
    }

    public function failed()
    {
        return Inertia::render('user/failed');
    }
}