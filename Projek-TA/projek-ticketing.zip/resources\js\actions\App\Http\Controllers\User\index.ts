import UserController from './UserController'
import UserTicketController from './UserTicketController'
import CheckoutController from './CheckoutController'
import SummaryController from './SummaryController'
import PaymentController from './PaymentController'
const User = {
    UserController: Object.assign(UserController, UserController),
UserTicketController: Object.assign(UserTicketController, UserTicketController),
CheckoutController: Object.assign(CheckoutController, CheckoutController),
SummaryController: Object.assign(SummaryController, SummaryController),
PaymentController: Object.assign(PaymentController, PaymentController),
}

export default User