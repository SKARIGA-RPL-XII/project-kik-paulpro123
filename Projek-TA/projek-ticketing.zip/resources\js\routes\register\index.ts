import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
 * @route '/register'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/register',
} satisfies RouteDefinition<["post"]>

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
 * @route '/register'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
 * @route '/register'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
 * @route '/register'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::store
 * @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:53
 * @route '/register'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Eo\RegisterEOController::eo
 * @see app/Http/Controllers/Eo/RegisterEOController.php:13
 * @route '/register/eo'
 */
export const eo = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: eo.url(options),
    method: 'post',
})

eo.definition = {
    methods: ["post"],
    url: '/register/eo',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Eo\RegisterEOController::eo
 * @see app/Http/Controllers/Eo/RegisterEOController.php:13
 * @route '/register/eo'
 */
eo.url = (options?: RouteQueryOptions) => {
    return eo.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Eo\RegisterEOController::eo
 * @see app/Http/Controllers/Eo/RegisterEOController.php:13
 * @route '/register/eo'
 */
eo.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: eo.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Eo\RegisterEOController::eo
 * @see app/Http/Controllers/Eo/RegisterEOController.php:13
 * @route '/register/eo'
 */
    const eoForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: eo.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Eo\RegisterEOController::eo
 * @see app/Http/Controllers/Eo/RegisterEOController.php:13
 * @route '/register/eo'
 */
        eoForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: eo.url(options),
            method: 'post',
        })
    
    eo.form = eoForm
const register = {
    store: Object.assign(store, store),
eo: Object.assign(eo, eo),
}

export default register