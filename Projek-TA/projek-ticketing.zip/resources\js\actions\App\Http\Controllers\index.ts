import User from './User'
import Eo from './Eo'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    User: Object.assign(User, User),
Eo: Object.assign(Eo, Eo),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers