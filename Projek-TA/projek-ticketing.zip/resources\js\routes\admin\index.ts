import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import accountsDb024e from './accounts'
import eo from './eo'
import events from './events'
/**
 * @see routes/web.php:139
 * @route '/admin/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/admin/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:139
 * @route '/admin/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:139
 * @route '/admin/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:139
 * @route '/admin/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:139
 * @route '/admin/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:139
 * @route '/admin/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:139
 * @route '/admin/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\Admin\AdminController::accounts
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
export const accounts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accounts.url(options),
    method: 'get',
})

accounts.definition = {
    methods: ["get","head"],
    url: '/admin/manage-akun',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\AdminController::accounts
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
accounts.url = (options?: RouteQueryOptions) => {
    return accounts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\AdminController::accounts
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
accounts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: accounts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\AdminController::accounts
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
accounts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: accounts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\AdminController::accounts
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
    const accountsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: accounts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\AdminController::accounts
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
        accountsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: accounts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\AdminController::accounts
 * @see app/Http/Controllers/Admin/AdminController.php:11
 * @route '/admin/manage-akun'
 */
        accountsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: accounts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    accounts.form = accountsForm
const admin = {
    dashboard: Object.assign(dashboard, dashboard),
accounts: Object.assign(accounts, accountsDb024e),
eo: Object.assign(eo, eo),
events: Object.assign(events, events),
}

export default admin